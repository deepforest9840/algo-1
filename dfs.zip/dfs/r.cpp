#include<bits/stdc++.h>


using namespace std;
const int N=1e3+10;
vector<int>graph[N];
stack<int>result;
bool vis[N];

void dfs(int vertex) {
    vis[vertex] = true;
    for (int child : graph[vertex]) {
        if (!vis[child]) {
            dfs(child);
        }
    }
    result.push(vertex);
}
void topologicalsort(int n){
    for(int i=0;i<n;i++){
        if(!vis[i]){
            dfs(i);
        }
    }
    while(!result.empty()){
        cout<<result.top()<<" ";
        result.pop();
    }
}




int main(){
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

	int n,m;//n is vertex and m is edges (number)
	for(int i=0;i<n;i++){
		int v1,v2;
		cin>>v1>>v2;
		graph[v1].push_back(v2);
	}
    topologicalsort(n);


}
