#include<bits/stdc++.h>

using namespace std;
const int N=1e3+10;
vector<int>graph[N];
stack<int>result;
bool vis[N];
vector<vector<int>>cc;
vector<int>current;
int loop=0;
bool flag;
int p1;

void dfs(int vertex,int par) {
    vis[vertex] = true;
    //current.push_back(vertex);
    for (int child : graph[vertex]) {
         if(vis[child]&&child!=par){

            loop++;
            flag=true;
            p1=child;
            current.push_back(vertex);
        }
        if (!vis[child]) {
            dfs(child,vertex);
        }
       
    }
    if(flag){
        if(p1==par){
            flag=false;

        }
        current.push_back(par);
    }
    
}



int main(){
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

	int n,m;//n is vertex and m is edges (number)
    cin>>n>>m;
	for(int i=0;i<m;i++){
		int v1,v2;
		cin>>v1>>v2;
		graph[v1].push_back(v2);
        //graph[v2].push_back(v1);
	}
    int ct=0;
    for(int i=1;i<=n;i++){
        if(!vis[i]){
            current.clear();
            dfs(i,0);
            cc.push_back(current);
           // ct++;
        }
    }
    cout<<loop<<endl;
    for(auto i:cc){

        for(int j:current){
            cout<<j<<" ";
        }
        cout<<endl;
    }

}

