#include<bits/stdc++.h>
using namespace std;

const int N = 1e3 + 10;
vector<int> graph[N];
vector<int> transposeGraph[N];
stack<int> result;
bool vis[N];
vector<vector<int>>cc;
vector<int>current;

void dfs1(int vertex) {
    vis[vertex] = true;
    
    for (int child : graph[vertex]) {
        if (!vis[child]) {
            dfs1(child);
        }
    }
    result.push(vertex);
}

void dfs2(int vertex) {
    current.push_back(vertex);
    vis[vertex] = true;
    for (int child : transposeGraph[vertex]) {
        if (!vis[child]) {
            dfs2(child);
        }
    }
}

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int n, m; // n is the number of vertices and m is the number of edges
    cin >> n >> m;

    for (int i = 0; i < m; i++) {
        int v1, v2;
        cin >> v1 >> v2;
        graph[v1].push_back(v2);
        transposeGraph[v2].push_back(v1); // Transpose the graph
    }

    memset(vis, false, sizeof(vis));
    for (int i = 1; i <= n; i++) {
        if (!vis[i]) {
            dfs1(i);
        }
    }

    memset(vis, false, sizeof(vis));
    int ct = 0;
    while (!result.empty()) {
        int vertex = result.top();
        result.pop();
        if (!vis[vertex]) {
            current.clear();
            dfs2(vertex);
            cc.push_back(current);
            ct++;
        }
    }

    cout << ct << endl;
    for(auto i:cc){
        for(int j:i){
            cout<<j<<" ";
        }
        cout<<endl;
    }

    return 0;
}
